"use client"
import React, { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { useRouter } from 'next/navigation';
import { BiRightArrowAlt } from "react-icons/bi";
import Footer2 from "../layout/Footer2";
import axios from "axios";
import { useSearchParams } from 'next/navigation';
import { useLanguage } from "../../app/contexts/LanguageContext"
import { useMatn } from "../../app/contexts/MatnContext"
import LoadingBox from "../layout/LoadingBox";
import {AiOutlineClose} from "react-icons/ai";
import { FaHeart, FaRegHeart, FaCheckCircle } from "react-icons/fa";
import { FiShare2 } from "react-icons/fi";

const colors =[
    {id:1,color:'white',nameFa:'سفید',nameEn:'white'},
    {id:2,color:'red',nameFa:'قرمز',nameEn:'red'},
    {id:3,color:'blue',nameFa:'آبی',nameEn:'blue'},
    {id:4,color:'red',nameFa:'قرمز',nameEn:'red'},
    {id:5,color:'white',nameFa:'سفید',nameEn:'white'},
    {id:6,color:'black',nameFa:'مشکی',nameEn:'black'},
    {id:7,color:'blue',nameFa:'آبی',nameEn:'blue'},
]

export default function Product({ src, zoom = 3 }) {
    let domain = "http://shayegandesign.com"
    const { locale } = useLanguage()
    const { textaslifa } = useMatn()
    const router = useRouter();
    const searchParams = useSearchParams();
    const uuid = searchParams.get('uuid');

    const [datas, setdatas] = useState({
        id: null,
        uuid: "",
        enable: null,
        color: "",
        fa_name: "",
        en_name: "",
        fa_desc: "",
        en_desc: "",
        product_group_id: null,
        product_group_uuid: "",
        fa_group_name: "",
        en_group_name: "",
        product_model_id: null,
        product_model_uuid: "",
        fa_model_name: "",
        en_model_name: "",
        main_image: "",
        banner_image: "",
        is_selective: 0,
        price: 0,
        currency: null,
        discount: 0,
    })
    const [features, setfeatures] = useState([])
    const [products, setproducts] = useState([])
    const [gallery, setgallery] = useState([])
    const [selectedImage, setSelectedImage] = useState();
    const [loadproduct, setloadproduct] = useState(true);
    const [colorpicker, setcolorpicker] = useState({id:1,nameFa:'سفید',nameEn:'white'});
    const [openModal, setopenModal] = useState(false);
    const [addbtn, setaddbtn] = useState(0);
    const [proCount, setproCount] = useState(0);
    const [desbtn, setdesbtn] = useState(0);
    
    useEffect(() => {
        const url = `api/viewproduct/${uuid}`;
        axios
        .get(url, { withCredentials: true })
        .then((response) => {
            setdatas(response.data)
            setgallery(response.data.Gallery)
            setfeatures(response.data.features)
            setSelectedImage(`${domain}/${response.data.Gallery[0].imgPath}`)
            const url2 = `api/productmodels?uuid=${response.data.product_model_uuid}`;
            axios
            .get(url2, { withCredentials: true })
            .then((response) => {
                setproducts(response.data[0].latestProducts)
                setloadproduct(false)
                
            })
            .catch((error) => {
                console.log(error)
            })
        })
        .catch((error) => {
            console.log(error)
        })
    }, [locale]);


    const container = {
        hidden: {},
        show: {
          transition: {
            staggerChildren: 0.08,
          },
        },
    };
    const wordd = {
        hidden: { y: 100, opacity: 1 },
        show: { y: 0, opacity: 1, transition: { duration: 0.6, ease: "easeOut" } },
    };
 

    const [descWords, setDescWords] = useState([]);
    const [titleWords, setTitleWords] = useState([]);
    useEffect(() => {
    if (!datas.fa_desc) return;
    let description = `${locale === "fa" ? `${datas.fa_desc}` : `${datas.en_desc}`}`;
    let title = `${locale === "fa" ? `${datas.fa_name}` : `${datas.en_name}`}`;
    
    const timer = setTimeout(() => {
        setDescWords(description.split(" "));
        setTitleWords(title.split(" "));
    }, 100); 

    return () => clearTimeout(timer);
    }, [datas.fa_desc,locale]);


    const tableanime = {
        hidden: { opacity: 0, y: 30 },
        show: { opacity: 1, y: 0, transition: { delay: 0.4, duration: 0.6, ease: "easeOut" }},
    };

    const [showLens, setShowLens] = useState(false);
    const [lensPosition, setLensPosition] = useState({ x: 0, y: 0 });
    const imgRef = useRef(null);

    const handleMouseMove = (e) => {
        const { top, left, width, height } = imgRef.current.getBoundingClientRect();
        const x = e.clientX - left;
        const y = e.clientY - top;

        setLensPosition({ x, y });
        setShowLens(true);
    };

    const handleMouseLeave = () => {
        setShowLens(false);
    };

// ---------------------- sectin 3----------------------------------
    const boxVariant = {
        hidden: { opacity: 0, y: 50 },
        visible: (i) => ({
        opacity: 1,
        y: 0,
        transition: { delay: i * 0.05, duration: 0.6, ease: "easeOut" },
        }),
    };
    const imageVariant = {
        hidden: { scale: 0, opacity: 1 },
        visible: (i) => ({
        opacity: 1,
        scale: 1,
        transition: { delay: i * 0.1, duration: 0.6, ease: "easeOut" },
        }),
    };
    const textVariant = {
        hidden: { opacity: 0, y: 30 },
        visible: { opacity: 1, y: 0, transition: { delay: 1.4, duration: 0.6, ease: "easeOut" }},
    };
    const [hoveredIndex, setHoveredIndex] = useState(null);
    const [slideIndex, setSlideIndex] = useState({});
    const [containerWidth, setContainerWidth] = useState(0);

    const [dragX, setDragX] = useState({});
    const startXRef = useRef({});
    const isDraggingX = useRef({});
    const thresholdX = 100;

    const handleDragStartX = (clientX, index) => {
    startXRef.current[index] = clientX;
    isDraggingX.current[index] = true;
    };

    const handleDragMoveX = (clientX, index) => {
    if (!isDraggingX.current[index]) return;
    const diff = (clientX - startXRef.current[index]) * 0.6;
    setDragX(prev => ({ ...prev, [index]: diff }));
    };

    const handleDragEndX = (box, index) => {
    if (!isDraggingX.current[index]) return;

    const current = slideIndex[index] || 0;
    const max = box.gallery.length - 1;
    const dx = dragX[index] || 0;

    if (dx < -thresholdX && current < max) {
        setSlideIndex(prev => ({ ...prev, [index]: current + 1 }));
    } 
    else if (dx > thresholdX && current > 0) {
        setSlideIndex(prev => ({ ...prev, [index]: current - 1 }));
    }

    isDraggingX.current[index] = false;
    startXRef.current[index] = null;
    setDragX(prev => ({ ...prev, [index]: 0 }));
    };

    const imageVariant2 = {
        hidden: { x: -1000,y:0, opacity: 0 },
        visible: (i) => ({
        opacity: 1,
        x: 1,
        y:0,
        transition: { delay: i * 0.5, duration: 2, ease: "easeOut" },
        }),
    };






    const [isFilled, setIsFilled] = useState(false);
    const toggleHeart = () => {
        setIsFilled(!isFilled);
    };

    const handleShare = () => {
        if (navigator.share) {
          navigator.share({
            title: datas.fa_name,
            url: `https://lariran.com/product?uuid=${datas.uuid}`,
          }).then(() => {
            console.log('Shared successfully');
          }).catch((err) => {
            console.error('Error sharing:', err);
          });
        } else {
          alert("مرورگر شما از اشتراک‌گذاری پشتیبانی نمی‌کند.");
        }
    };



    return (
        <>
            {loadproduct ? <LoadingBox/> :   
            <> 
                <div style={{background:`${datas.color}`}}>
                    {/* Section 1 */}
                    <div className="w-full md:h-[85vh] sm:h-auto">
                        <div dir="rtl" className="md:flex sm:block pt-[100px] pb-[50px] gap-5 h-full relative w-[90%] ml-[5%]">
                            <div dir="ltr" className="md:w-3/5 sm:w-full h-full md:flex sm:block gap-2 ">
                                <div className="md:w-4/5 sm:w-full h-calc(100% - 150px)">
                                <div
                                    className="rounded border border-gray-500 md:p-2 sm:p-1"
                                    style={{ position: 'relative', width: '100%', height:'100%' }}
                                    onMouseMove={handleMouseMove}
                                    onMouseLeave={handleMouseLeave}
                                >
                                    <div className="absolute left-3 top-3">
                                        <button onClick={toggleHeart} className="border-none cursor-pointer flex">
                                        {isFilled ? <FaHeart color="red" /> : <FaRegHeart className="text-footert"/>}
                                        </button>
                                        <button onClick={handleShare} className="cursor-pointer mt-2">
                                        <FiShare2 className="text-footert"/>
                                        </button>
                                    </div>
                                    <img ref={imgRef} src={selectedImage} alt="photo" className="flex mx-auto w-auto h-full object-contain" />
                                    {showLens && (
                                        <div
                                        style={{
                                            position: 'absolute',
                                            top: lensPosition.y - 50,
                                            left: lensPosition.x - 50,
                                            width: '200px',
                                            height: '200px',
                                            borderRadius: '50%',
                                            overflow: 'hidden',
                                            border: '2px solid #ccc',
                                            boxShadow: '0 0 5px rgba(0,0,0,0.3)',
                                            pointerEvents: 'none',
                                            backgroundImage: `url(${selectedImage})`,
                                            backgroundRepeat: 'no-repeat',
                                            backgroundSize: `${imgRef.current.width * zoom}px ${imgRef.current.height * zoom}px`,
                                            backgroundPosition: `-${lensPosition.x * zoom - 50}px -${lensPosition.y * zoom - 50}px`,
                                        }}
                                        />
                                    )}
                                </div>
                                </div>
                                <div className="gallery-scroll px-1 md:w-1/5 sm:w-full md:h-calc(100% - 150px) sm:h-auto md:block sm:flex md:mt-0 sm:mt-3 gap-2 overflow-auto md:space-y-3 sm:space-y-0">
                                    {gallery.map((img, index) => (
                                        <img
                                        key={index}
                                        src={`${domain}/${img.imgPath}`}
                                        alt={`Thumbnail ${index}`}
                                        className={`md:w-full sm:w-20 md:h-auto sm:h-auto object-contain md:p-2 sm:p-1 rounded cursor-pointer border ${
                                            selectedImage === `${domain}/${img.imgPath}` ? "border-gray-600" : "border-gray-400"
                                        }`}
                                        onClick={() => setSelectedImage(`${domain}/${img.imgPath}`)}
                                        />
                                    ))}
                                </div>
                            </div>
                            <div dir={locale === "fa" ? "rtl" : "ltr"} className="md:w-2/5 sm:w-full">
                                {titleWords.length > 0 && (
                                <motion.h1 dir={locale === "fa" ? "rtl" : "ltr"} variants={container} initial="hidden" animate="show" className="md:text-[40px] sm:text-[25px] font-bold md:mt-0 sm:mt-8 flex flex-wrap">
                                    {titleWords.map((word, idx) => (
                                        <span
                                            key={idx}
                                            className="overflow-hidden inline-block mb-2 text-[#47221C] md:h-[55px] sm:h-10"
                                        >
                                        <motion.span variants={wordd} className={`${idx == 0 ? 'md:mr-0 sm:mr-0' : `${locale === "fa" ? 'md:mr-3 sm:mr-2' : 'md:ml-3 sm:ml-2'}`} inline-block`}>
                                            {word}
                                        </motion.span>
                                        </span>
                                    ))}
                                </motion.h1>
                                )}
                                <div className="md:mt-5 sm:mt-3 w-full">  
                                    <motion.p variants={tableanime} initial="hidden" animate="show" className="md:text-[18px] sm:text-[14px] flex flex-wrap text-[#47221C]">
                                        {locale === "fa" ? `ویژگی های محصول` : `Products features`}
                                    </motion.p>
                                    <motion.ul initial="hidden" animate="show" variants={tableanime} className="mt-3">
                                        {features.slice(0,3).map((box, boxIndex) => {
                                            return (
                                                <li key={boxIndex} className="border-b border-[#41241e] w-full flex gap-5 justify-between mt-3 pb-1 text-[#47221C] md:text-[14px] sm:text-[12px]">
                                                    <span>{locale === "fa" ? `${box.feature_fa_name}` : `${box.feature_en_name}`}</span>
                                                    <span>{locale === "fa" ? `${box.fa_value}` : `${box.en_value}`}</span>
                                                </li>
                                            )
                                         })}
                                    </motion.ul>
                                </div>
                                <div className="md:mt-8 sm:mt-3 w-full">
                                    <motion.p variants={tableanime} initial="hidden" animate="show" className="md:text-[18px] sm:text-[14px] flex flex-wrap text-[#47221C]">
                                        {locale === "fa" ? `انتخاب رنگ` : `Choose color`} 
                                        <span className="md:text-[15px] sm:text-[12px] mr-1">
                                           : {locale === "fa" ? `${colorpicker.nameFa}` : `${colorpicker.nameEn}`}
                                        </span>
                                    </motion.p>
                                    <motion.div initial="hidden" animate="show" variants={tableanime} className="mt-3 flex gap-1">
                                        {colors.map((box, boxIndex) => {
                                            return (
                                                <span 
                                                onClick={()=>{
                                                    setcolorpicker({id:box.id,nameFa:box.nameFa,nameEn:box.nameEn})
                                                }}
                                                key={boxIndex} 
                                                style={{backgroundColor:`${box.color}`}} 
                                                className={`rounded-full border-[1.5px] md:w-8 md:h-8 sm:w-6 sm:h-6 cursor-pointer shadow-md hover:shadow-2xl
                                                    ${colorpicker.id == box.id ? 'border-gray-600' : 'border-gray-300'}
                                                `}></span>
                                            )
                                         })}
                                    </motion.div>
                                </div>
                                <div dir="ltr" className="md:mt-8 sm:mt-3 w-full">
                                    <motion.p variants={tableanime} initial="hidden" animate="show" className="font-bold md:text-[18px] sm:text-[14px] flex flex-wrap text-[#47221C]">
                                           {new Intl.NumberFormat().format(datas.price)} {datas.currency} 
                                    </motion.p>
                                    {datas.discount == 0 ? (
                                        <></>
                                    ):(
                                        <motion.p  variants={tableanime} initial="hidden" animate="show" className="md:text-[18px] sm:text-[14px] flex flex-wrap text-[#47221C]">
                                           {new Intl.NumberFormat().format(datas.discount)} {datas.currency}  
                                        </motion.p>
                                    )}
                                </div>
                                <div dir="ltr" className="md:mt-5 sm:mt-3 w-full">
                                    <motion.div initial="hidden" animate="show" variants={tableanime}>
                                    {addbtn == 0 ? (
                                        <button 
                                        onClick={()=>{
                                            setaddbtn(1);
                                            setproCount(proCount+1)
                                            setopenModal(true);
                                            const timer = setTimeout(() => {
                                                setopenModal(false)
                                            }, 6000);
                                        }}      
                                        className="border border-[#47221C] text-[#47221C] md:px-4 sm:px-3 md:py-2 sm:py-[6px] md:text-[15px] sm:text-[13px] rounded hover:bg-[#47221C10]">
                                            {locale === "fa" ? `افزودن به سبد خرید` : `Add to basket`}
                                        </button>
                                    ) : (
                                        <div className="w-[110px] flex gap-2 justify-between py-1 px-3 border border-[#47221C] rounded">
                                            <button className="pr-2 border-r border-[#47221C]" onClick={()=>{
                                                setaddbtn(0);
                                                setproCount(0)
                                            }}>
                                                <svg className="w-5" width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path fillRule="evenodd" clipRule="evenodd" d="M11.7511 5.64747C12.0473 5.67185 12.2682 5.93076 12.2446 6.22697C12.2403 6.27574 11.8515 11.0889 11.6278 13.1078C11.4886 14.3608 10.661 15.1232 9.4116 15.1461C8.45556 15.1626 7.53324 15.172 6.63171 15.172C5.6599 15.172 4.71247 15.1612 3.77508 15.1418C2.57591 15.1182 1.74611 14.3407 1.61056 13.1129C1.38464 11.076 0.998063 6.27502 0.994477 6.22697C0.970092 5.93076 1.19099 5.67113 1.4872 5.64747C1.7791 5.63958 2.04303 5.8447 2.0667 6.14019C2.06899 6.17132 2.22702 8.13189 2.39924 10.0717L2.43383 10.4588C2.52057 11.423 2.60849 12.3495 2.67991 12.9945C2.75665 13.6924 3.13318 14.0524 3.79731 14.066C5.59033 14.104 7.41992 14.1062 9.39223 14.0703C10.098 14.0567 10.4795 13.7038 10.5584 12.9895C10.7807 10.9856 11.168 6.18896 11.1723 6.14019C11.196 5.8447 11.4578 5.63814 11.7511 5.64747ZM8.13698 0.828064C8.79537 0.828064 9.37416 1.27201 9.54414 1.90817L9.72631 2.81257C9.78517 3.10904 10.0454 3.32556 10.3466 3.33031L12.7003 3.33039C12.9972 3.33039 13.2382 3.57137 13.2382 3.8683C13.2382 4.16522 12.9972 4.4062 12.7003 4.4062L10.3676 4.40609C10.364 4.40616 10.3604 4.4062 10.3567 4.4062L10.3392 4.40548L2.89867 4.40611C2.89289 4.40617 2.88709 4.4062 2.8813 4.4062L2.87025 4.40548L0.537904 4.4062C0.240981 4.4062 0 4.16522 0 3.8683C0 3.57137 0.240981 3.33039 0.537904 3.33039L2.89105 3.32968L2.96351 3.32509C3.23338 3.29008 3.45767 3.08511 3.51244 2.81257L3.68672 1.94045C3.86387 1.27201 4.44266 0.828064 5.10105 0.828064H8.13698ZM8.13698 1.90387H5.10105C4.92892 1.90387 4.77759 2.01934 4.73384 2.18502L4.56673 3.02415C4.54549 3.13043 4.51457 3.23286 4.47499 3.33059H8.76325C8.72363 3.23286 8.69263 3.13043 8.6713 3.02415L8.49702 2.15202C8.46044 2.01934 8.30911 1.90387 8.13698 1.90387Z" fill="#FF6666"/>
                                                </svg>
                                            </button>
                                            <div className="flex gap-2 text-[15px]">
                                                <button onClick={()=>{
                                                    if(proCount == 1){
                                                        setproCount(proCount-1)
                                                        setaddbtn(0);
                                                    }
                                                    else{
                                                        setproCount(proCount-1)
                                                    }
                                                }}>-</button>
                                                <span>{proCount}</span>
                                                <button
                                                onClick={()=>{
                                                    setproCount(proCount+1)
                                                }}
                                                >+</button>
                                            </div>
                                        </div>
                                    )}
                                    </motion.div>
                                </div>
                                {openModal && (
                                    <div className="fixed inset-0 bg-black bg-opacity-30 z-[100] flex items-end md:items-center md:mb-auto sm:-mb-2 justify-center">
                                        <section className="md:max-w-[700px] sm:w-full backdrop-blur-[20px] bg-[#FFFFFF40] rounded-xl p-4 border border-redweb relative">
                                            <h1 className={`text-greenbtn font-bold md:text-[18px] sm:text-[14px] ${locale === "fa" ? 'md:pr-4 sm:pr-3 mr-2' : 'md:pl-4 sm:pl-3 ml-2'} relative`}>
                                            {locale === "fa" ? `این کالا به سبد خرید اضافه شد!` : `This Product added to basket`}
                                            <FaCheckCircle className={`absolute ${locale === "fa" ? 'md:-right-3 sm:-right-2' : 'md:-left-3 sm:-left-2'} top-0 md:text-2xl sm:text-lg text-[#47221C]`} />
                                            </h1>
                                            <span
                                            className={`${locale === "fa" ? 'left-4' : 'right-4'} absolute top-4 cursor-pointer`}
                                            onClick={() => setopenModal(false)}
                                            >
                                            <AiOutlineClose className="text-white text-lg" />
                                            </span>
                                            <hr className="my-2" />
                                            <div className="flex items-center md:gap-4 sm:gap-2 mt-4">
                                            <img
                                                src={selectedImage}
                                                alt="shayegan"
                                                className="md:w-36 md:h-36 sm:w-24 sm:h-24 object-contain"
                                            />
                                            <div className="">
                                                <p className="md:text-[15px] sm:text-[12px] font-semibold text-[#47221C]">{locale === "fa" ? `${datas.fa_name}` : `${datas.en_name}`}</p>
                                                <p className="md:text-[15px] sm:text-[12px] font-semibold text-[#47221C] mt-3">
                                                 {locale === "fa" ? `رنگ` : `Color`} : {locale === "fa" ? `${colorpicker.nameFa}` : `${colorpicker.nameEn}`}
                                                </p>
                                            </div>
                                            </div>
                                            <button
                                            onClick={() => router.push('/basket')}
                                            className="mt-4 w-full border border-[#47221C] hover:bg-[#47221C10] text-[#47221C] md:text-[18px] sm:text-[14px] font-bold py-2 rounded"
                                            >
                                            {locale === "fa" ? `برو به سبد خرید` : `Direct to basket`}
                                            </button>
                                        </section>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                
                    {/* Section 2 */}
                    <div dir={locale === "fa" ? "rtl" : "ltr"} className="relative md:mt-8 sm:mt-3 w-[90%] ml-[5%]">
                        {/* <img
                        src={`${domain}/${datas.banner_image}`}
                        className="absolute top-0 left-0 w-full h-full object-cover scale-105"
                        style={{ transform: 'translateY(-20%)', transition: 'transform 0.5s ease-out' }}
                        alt="banner"
                        data-scroll
                        data-scroll-speed="-2"
                        /> */}
                        <motion.div variants={tableanime} initial="hidden" animate="show" style={{background:`${datas.color}`}} className="border-b border-gray-500 flex gap-2 w-full mx-auto py-2 px-3 md:text-[18px] sm:text-[14px] text-[#47221C]">
                            <button className={`mx-auto `} onClick={()=>{
                                setdesbtn(0)
                            }}>
                                {locale === "fa" ? ` توضیحات ` : ` Description`}
                            </button>
                        </motion.div>
                        <motion.p variants={tableanime} initial="hidden" animate="show" className="md:mt-7 sm:mt-5 md:text-[15px] sm:text-[12px] text-[#47221C] flex flex-wrap mt-3">
                            {locale === "fa" ? `${datas.fa_desc}` : `${datas.en_desc}`}
                        </motion.p>

                        <motion.ul initial="hidden" animate="show" variants={tableanime} className="mt-8">
                            {features.map((box, boxIndex) => {
                                return (
                                    <li key={boxIndex} className="border-b border-[#41241e] w-full flex gap-5 justify-between mt-3 pb-1 text-[#47221C] md:text-[15px] sm:text-[12px]">
                                        <span>{locale === "fa" ? `${box.feature_fa_name}` : `${box.feature_en_name}`}</span>
                                        <span>{locale === "fa" ? `${box.fa_value}` : `${box.en_value}`}</span>
                                    </li>
                                )
                            })}
                        </motion.ul>
                    </div>
                
                    {/* Section 3 */}
                    <div className="w-full mt-16 relative px-4">
                        <h3 className="text-center text-[#47221C] md:text-[18px] sm:text-[14px]">
                            {locale === "fa" ? `محصولات مشابه` : `Similar products`}
                        </h3>
                        <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 my-5">
                            {products.map((box, boxIndex) => {
                            const gallery = box.gallery.length ? box.gallery : [{ imgPath: box.imgPath }];
                            return (
                                <motion.div
                                key={boxIndex}
                                custom={boxIndex}
                                initial="hidden"
                                whileInView="visible"
                                viewport={{ once: true, amount: 0.3 }}
                                variants={boxVariant}
                                className="flex flex-col items-center relative"
                                onMouseEnter={() => setHoveredIndex(boxIndex)}
                                onMouseLeave={() => setHoveredIndex(null)}
                                >
                                    <motion.div className="relative w-full h-64 overflow-hidden rounded-lg bg-transparent border border-gray-300">
                                        <div
                                        style={{ width: "100%", overflow: "hidden", touchAction: "none", userSelect: "none" }}
                                        onTouchStart={(e) => handleDragStartX(e.touches[0].clientX, boxIndex)}
                                        onTouchMove={(e) => handleDragMoveX(e.touches[0].clientX, boxIndex)}
                                        onTouchEnd={() => handleDragEndX(box, boxIndex)}
                                        onMouseDown={(e) => { e.preventDefault(); handleDragStartX(e.clientX, boxIndex); }}
                                        onMouseMove={(e) => { if (isDraggingX.current[boxIndex]) { e.preventDefault(); handleDragMoveX(e.clientX, boxIndex); }}}
                                        onMouseUp={() => handleDragEndX(box, boxIndex)}
                                        onMouseLeave={() => handleDragEndX(box, boxIndex)}
                                        >
                                        <motion.div
                                            style={{ display: "flex", cursor: "grab" }}
                                            animate={{ x: -((slideIndex[boxIndex] || 0) * containerWidth) + (dragX[boxIndex] || 0) }}
                                            transition={{ type: "spring", stiffness: 80, damping: 50, mass: 1 }}
                                        >
                                            {gallery.map((src, i) => (
                                            <motion.div
                                                key={i}
                                                ref={(el) => el && i === 0 && setContainerWidth(el.offsetWidth)}
                                                style={{ minWidth: "100%" }}
                                                className="flex items-center justify-center relative"
                                                variants={imageVariant}
                                                initial="hidden"
                                                whileInView="visible"
                                                viewport={{ once: true, amount: 0.3 }}
                                            >
                                                <img
                                                src={`${domain}/${src.imgPath}`}
                                                alt={`slide-${i}`}
                                                draggable={false}
                                                className="pointer-events-none h-64 md:w-[55%] sm:w-[70%] object-contain"
                                                />
                                            </motion.div>
                                            ))}
                                        </motion.div>
                                        </div>
                                        <div className="absolute bottom-2 left-0 right-0 h-1 bg-gray-200 rounded-full mx-2">
                                        <div
                                            className="h-1 bg-gray-600 rounded-full transition-all duration-300"
                                            style={{
                                            width: `${(((slideIndex[boxIndex] || 0) + 1) / gallery.length) * 100}%`,
                                            }}
                                        ></div>
                                        </div>

                                        <motion.button
                                            initial={{ opacity: 1, y: -43 }}
                                            animate={hoveredIndex === boxIndex ? { opacity: 1, y: 1 } : { opacity: 1, y: -43 }}
                                            transition={{ duration: 0.3, ease: "easeOut" }}
                                            className="absolute flex gap-[1px] top-2 right-2 text-white cursor-pointer"
                                            onClick={()=>{
                                                router.push(`/collection?uuid=${box.uuid}`)
                                            }}
                                        >
                                            <motion.p
                                            initial={{ scale: 1 }}
                                            whileHover={{ scale: 1.05 }}
                                            className="text-white px-2 py-1 rounded-sm shadow text-[13px] bg-[#222222] inline-flex"
                                            >
                                            {locale === "fa" ? "مشاهده" : "explore"}
                                            </motion.p>
                                            <span className="text-white">
                                            <BiRightArrowAlt
                                                size={30}
                                                className="text-white  px-[7px] h-[27.5px] rounded-sm shadow bg-[#222222] inline-flex"
                                            />
                                            </span>
                                        </motion.button>

                                        <motion.p 
                                        variants={imageVariant2}
                                        className="absolute left-2 bottom-5 md:text-[15px] sm:text-[13px] font-light text-gray-600 bg-[#f5f6ee10] backdrop-blur-[20px] p-1 rounded-sm border border-gray-300">
                                            {box.translations[locale].title}
                                        </motion.p>
                                        <motion.p 
                                        dir={locale === "fa" ? "rtl" : "ltr"}
                                        variants={imageVariant2}
                                        className="absolute left-2 top-2.5 md:text-[15px] sm:text-[13px] font-light text-gray-600 bg-[#f5f6ee10] p-1 rounded-sm border border-gray-300">
                                            {new Intl.NumberFormat().format(box.Price)} {box.Currency} 
                                        </motion.p>
                        
                                        {box.Discount == 0 ? (
                                            <></>
                                        ):(
                                            <motion.p 
                                            dir={locale === "fa" ? "rtl" : "ltr"}
                                            variants={imageVariant2}
                                            className="absolute left-2 top-12 md:text-[15px] sm:text-[13px] font-light text-gray-600 bg-[#f5f6ee10] p-1 rounded-full border border-gray-300">
                                            {box.discount}
                                            </motion.p>
                                        )}
                                    </motion.div>
                                </motion.div>
                            )
                            })}
                            
                        </div>
                    </div>
                    <Footer2/>
                </div>
            </>
            }
        </>
    );
}