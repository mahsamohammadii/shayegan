"use client";

export default function Sec2Panel() {

  return (
    <>
        <div dir="rtl" className="border border-[#47221C] rounded-xl px-2 pt-2">
            <h6 className="md:text-[18px] sm:text-[15px] text-black p-2 rounded-[10px] border border-[#47221C] text-center">ویرایش اطلاعات </h6>
            <div className="md:mt-3 xs:mt-2">
                <label className="md:text-[15px] xs:text-[10px] text-right">  نام و نام خانوادگی</label>
                <input className="md:px-3 xs:px-2 md:py-2 xs:py-1 md:text-[15px] xs:text-[10px] rounded-md bg-transparent border border-[#47221C] md:mb-4 xs:mb-2 md:mt-2 xs:mt-1 w-full outline-none" placeholder="نام و نام خانوادگی"/>
                <label className="md:text-[15px] xs:text-[10px] text-right">شماره موبایل</label>
                <input className="md:px-3 xs:px-2 md:py-2 xs:py-1 md:text-[15px] xs:text-[10px] rounded-md bg-transparent border border-[#47221C] md:mb-4 xs:mb-2 md:mt-2 xs:mt-1 w-full outline-none" placeholder="شماره موبایل"/>
            </div>
            <div className="w-full">
                <button className="w-full md:text-[16px] sm:text-[13px] text-white p-2 rounded-[10px] bg-[#363635] text-center my-2">ویرایش </button>
            </div>
        </div>
    </>
  );
}
