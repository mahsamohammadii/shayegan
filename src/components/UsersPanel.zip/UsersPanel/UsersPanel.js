"use client";
import Link from "next/link";
import React,{ useState, useEffect }  from 'react';
import HeroSecPanel from "./HeroSecPanel/HeroSecPanel";

import { CiUser } from "react-icons/ci";
import { CiEdit } from "react-icons/ci";
import { CiFloppyDisk } from "react-icons/ci";
import { CiHeart } from "react-icons/ci";
import { CiChat1 } from "react-icons/ci";
import { CiMonitor } from "react-icons/ci";
import { CiMail } from "react-icons/ci";
import { CiBellOn } from "react-icons/ci";
import { TiKey } from "react-icons/ti";
import { CiLogout } from "react-icons/ci";
import { CiGrid42 } from "react-icons/ci";
import { CgMenuLeftAlt } from "react-icons/cg";
import Sec1Panel from "./Sec1Panel/Sec1Panel";
import Sec2Panel from "./Sec2Panel/Sec2Panel";
import Sec3Panel from "./Sec3Panel/Sec3Panel";
import Sec4Panel from "./Sec4Panel/Sec4Panel";
import Sec5Panel from "./Sec5Panel/Sec5Panel";
import Sec6Panel from "./Sec6Panel/Sec6Panel";


const tabs =[
  {name:'داشبورد',icon:<CiGrid42/>,id:1},
  {name:'اطلاعات حساب کاربری',icon:<CiUser/>,id:2},
  {name:'سفارشات',icon:<CiUser/>,id:3},
  {name:'علاقمندی ها',icon:<CiHeart/>,id:4},
  {name:'ارتباط با پشتیبانی',icon:<CiChat1/>,id:5},
  {name:'اعلان ها',icon:<CiBellOn/>,id:6},
  {name:'خروج از حساب کاربری',icon:<CiLogout/>,id:7},
]

export default function UsersPanel() {

  const [activeTab, setActiveTab] = useState(1);

  const [isMobile, setIsMobile] = useState(false);
  const [showMobileNav, setShowMobileNav] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 899);
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);


  return (
    <>
      {/* <HeroSecPanel/> */}
      <div dir="rtl" className="md:w-[90%] xs:w-[95%] mx-auto md:mt-16 xs:mt-6 pb-20">
        {isMobile ? (
          <div className="flex items-center justify-between text-white bg-consbg p-2 rounded-xl text-[18px]">
            <p>
            به پنل کاربری هایپر صنعت خوش آمدید
            </p>
            <button onClick={() => setShowMobileNav(true)}>
              <CgMenuLeftAlt className="text-[23px]"/>
            </button>
          </div>
        ) : (
          <h6 className="text-[24px] text-black border border-[#47221C] p-2 rounded-xl text-center font-medium">به پنل کاربری شایگان دیزاین خوش آمدید</h6>
        )}
        <div className="flex flex-1 gap-4 md:mt-5 xs:mt-3">
          {isMobile && (
            <div
              className={`fixed bottom-0 left-0 w-full bg-white rounded-t-2xl shadow-xl z-50
                          transition-transform duration-500 ease-in-out 
                          ${showMobileNav ? "translate-y-0" : "translate-y-full"}`}
            >
              <div className="p-5">
                <div className="flex justify-between">
                  <h5 className="text-[15px]">نام کاربر</h5>
                  <button onClick={() => setShowMobileNav(false)}>✕</button>
                </div>
                <h5 className="text-[12px] text-gray-500">09111111111</h5>

                <div className="mt-4 flex flex-col">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setActiveTab(tab.id);
                        setShowMobileNav(false);
                      }}
                      className={`flex items-center text-[12px] gap-2 md:px-4 xs:px-2 h-8 border-t border-gray-300 transition-colors ${
                        activeTab === tab.id
                          ? "text-[#89C8D4] font-semibold"
                          : "text-gray-600 hover:text-gray-800"
                      }`}
                    >
                      <span className="text-[15px]">
                        {tab.icon}
                      </span>
                      {tab.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
          {!isMobile && (
          <div className="relative w-[27%]">
            <div className="border border-[#47221C] rounded-xl p-5 shadow-sec1shadow sticky top-20 right-0 w-full">
              <div className="">
                <div className="mt-2 flex justify-between items-center">
                  <div className="text-black">
                    <h5 className="text-[16px]">نام کاربر</h5>
                    <p className="text-[12px] mt-1">09387913729</p>
                  </div>
                  <div>
                    <button onClick={() => setActiveTab(2)}>
                      <CiEdit className="text-[30px] text-[#47221C]"/>
                    </button>
                  </div>
                </div>
                <div className="relative w-full mt-4">
                  <div className="flex flex-col relative">
                    <div
                      className="absolute -right-5 w-1 bg-[#47221C] transition-all duration-300 rounded-l-md"
                      style={{
                        top: `${(activeTab - 1) * 48}px`,
                        height: "48px",
                      }}
                    />
                    {tabs.map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`flex items-center justify-between px-4 h-12 text-right transition-colors duration-300 border-t border-[#47221C] ${
                          activeTab === tab.id
                            ? "text-[#47221C] font-semibold"
                            : "text-gray-600 hover:text-gray-800"
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <span
                            className={`text-lg transition-colors ${
                              activeTab === tab.id ? "text-[#47221C]" : "text-gray-600"
                            }`}
                          >
                            {tab.icon}
                          </span>
                          {tab.name}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
          )}
          <div className="md:w-[72.7%] xs:w-full md:mr-[.3%] xs:mr-0">
            {activeTab == 1 && (
            <Sec1Panel setActiveTab={setActiveTab}/>
            )}
            {activeTab == 2 && (
            <Sec2Panel/>
            )} 
            {activeTab == 3 && (
            <Sec3Panel/>
            )}
            {activeTab == 4 && (
            <Sec4Panel/>
            )} 
            {activeTab == 5 && (
            <Sec5Panel/>
            )} 
            {activeTab == 6 && (
            <Sec6Panel/>
            )}                 
          </div>
        </div>
      </div>
    </>
  )
}