"use client";
import { FaTelegramPlane } from "react-icons/fa";
import { FaWhatsapp } from "react-icons/fa";
import { FaInstagram } from "react-icons/fa";
import { FaEnvelope } from "react-icons/fa";
import { FaTwitter } from "react-icons/fa";
import { FaFacebookF } from "react-icons/fa";
import { FaMapMarkerAlt } from "react-icons/fa";
import { FaPhone } from "react-icons/fa";

export default function Sec5Panel() {

  return (
    <>

        <div dir="rtl" className="border border-[#47221C] rounded-xl px-2 py-2">
            <h6 className="md:text-[18px] sm:text-[15px] text-black p-2 rounded-[10px] border border-[#47221C] text-center">ارتباط با ما</h6>
            <div className="grid grid-cols-2 gap-2 mt-5">
                <div className="space-y-3 md:text-[18px] sm:text-[13px] text-black">
                    <div className="flex items-center md:gap-2 xs:gap-1">
                        <FaPhone className="text-[20px]"/>
                        <a dir="ltr" href="tel:+02191096166">
                            021 &nbsp;&nbsp;&nbsp; 9109 &nbsp;61 &nbsp;66
                        </a>
                    </div>
                    <div className="flex items-center md:gap-2 xs:gap-1">
                        <FaEnvelope className="text-[20px]"/>
                        <a dir="ltr" href="tel:+02191096166">
                            abcdefghij123456@gmail.com
                        </a>
                    </div>
                    <div className="flex items-center md:gap-2 xs:gap-1">
                        <FaMapMarkerAlt className="text-[20px]"/>
                        <p>
                            ذثیل ثتاث ثتباث
                        </p>
                    </div>
                </div>
                <div className="text-sm flex gap-2 justify-end ">
                    <a  target="_blanck"><FaTelegramPlane size={30} className="text-[#363635] p-1 border border-[#363635] rounded-full cursor-pointer hover:text-[#ba631b] hover:border-[#ba631b]"/></a>
                    <a target="_blanck"><FaFacebookF size={30} className="text-[#363635] p-1 border border-[#363635] rounded-full cursor-pointer hover:text-[#ba631b] hover:border-[#ba631b]"/></a>
                    <a target="_blanck"><FaWhatsapp size={30} className="text-[#363635] p-1 border border-[#363635] rounded-full cursor-pointer hover:text-[#ba631b] hover:border-[#ba631b]"/></a>
                    <a target="_blanck"><FaInstagram size={30} className="text-[#363635] p-1 border border-[#363635] rounded-full cursor-pointer hover:text-[#ba631b] hover:border-[#ba631b]"/></a>
                    <a target="_blanck"><FaTwitter size={30} className="text-[#363635] p-1 border border-[#363635] rounded-full cursor-pointer hover:text-[#ba631b] hover:border-[#ba631b]"/></a>
                </div>
            </div>
        </div>
    </>
  );
}
