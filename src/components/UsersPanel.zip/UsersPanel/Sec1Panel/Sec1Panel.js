"use client";

export default function Sec1Panel({setActiveTab}) {

  return (
    <>
        <div dir="ltr" className="border border-[#47221C] rounded-xl px-2 pt-2">
            <div className="h-auto md:max-h-[500px] sm:max-h-[350px] overflow-y-auto overflow-x-hidden">
            <h6 className="md:text-[18px] sm:text-[15px] text-black p-2 rounded-[10px] border border-[#47221C] text-center">آخرین سفارشات شما</h6>
            {[...Array(3)].map((_, i) => (
            <div key={i} dir="rtl" className="flex items-center gap-2 w-full border-b border-[#47221C] md:py-1.5 sm:py-2">
                <img src="/images/sandali.png" className="md:w-[120px] sm:w-[80px]"/>
                <div className="w-full">
                    <div className="flex justify-between items-center">
                    <p className="md:text-[15px] sm:text-[10px] text-black font-bold">صندلی راحتی کرم </p>
                    </div>
                    <div className="flex justify-between items-center mt-2">
                    <p className="text-gray-500 md:text-[12px] sm:text-[9px]">{new Intl.NumberFormat().format('70000000')} ریال</p>
                    <button className="md:text-[14px] sm:text-[12px] py-2 px-4 rounded-[8px] bg-[#363635] text-white">مشاهده</button>
                    </div>
                </div>
            </div>
            ))}
            </div>
            <div className="w-full">
                <button onClick={()=>{setActiveTab(2)}} className="w-full md:text-[16px] sm:text-[13px] text-white p-2 rounded-[10px] bg-[#363635] text-center my-2">مشاهده همه </button>
            </div>
        </div>
    </>
  );
}
